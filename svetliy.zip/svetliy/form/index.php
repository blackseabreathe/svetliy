<?php


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
echo 'Error';
}

if(!isset($_POST['type']) || empty($_POST['type'])){
exit;
}



$error = [];

$type = $_POST['type'];



// форма в подвале
if($type == 'footerForm'){

if(!isset($_POST['name']) || mb_strlen($_POST['name']) < 2 || preg_match('/[^а-яёА-ЯЁ ]/iu', $_POST['name'])){
array_push($error, ['error' => 'name']);
}



if(!isset($_POST['tell']) || empty($_POST['tell']) || strpos($_POST['tell'], '_') !== false){
array_push($error, ['error' => 'tell']);
}


if(count($error) > 0){
echo json_encode(['error' => $error], JSON_UNESCAPED_UNICODE);
exit;
}


$name = $_POST['name'];
$tell = $_POST['tell'];
$date = date('d.m.Y H:i:s');

// тут далее пишешь отправку данных куда надо (mail/smtp/tg/bitrix/amo/macro...)





echo json_encode(['success' => 'done'], JSON_UNESCAPED_UNICODE); // ключ success - после успешной отправки формы
exit;

}




// обратный звонок
if($type == 'callback'){

if(!isset($_POST['name']) || mb_strlen($_POST['name']) < 2 || preg_match('/[^а-яёА-ЯЁ ]/iu', $_POST['name'])){
array_push($error, ['error' => 'name']);
}



if(!isset($_POST['tell']) || empty($_POST['tell']) || strpos($_POST['tell'], '_') !== false){
array_push($error, ['error' => 'tell']);
}


if(count($error) > 0){
echo json_encode(['error' => $error], JSON_UNESCAPED_UNICODE);
exit;
}


$name = $_POST['name'];
$tell = $_POST['tell'];
$date = date('d.m.Y H:i:s');

// тут далее пишешь отправку данных куда надо (mail/smtp/tg/bitrix/amo/macro...)





echo json_encode(['success' => 'done'], JSON_UNESCAPED_UNICODE); // ключ success - после успешной отправки формы
exit;






}

else{
exit;
}